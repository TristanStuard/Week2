import math
def calculate_sphere_properties(radius):
    diameter = 2 * radius
    circumference = 2 * math.pi * radius
    surface_area = 4 * math.pi * radius ** 2
    volume = (4/3) * math.pi * radius ** 3
    return diameter, circumference, surface_area, volume
# Input radius from the user
radius = float(input("Enter the radius of the sphere: "))
# Calculate the properties of the sphere
diameter, circumference, surface_area, volume = calculate_sphere_properties(radius)
# Output the results
print("Diameter:", diameter)
print("Circumference:", circumference)
print("Surface Area:", surface_area)
print("Volume:", volume)
