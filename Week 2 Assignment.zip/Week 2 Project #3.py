videos = int(input("Enter the number of new videos: "))
oldies = int(input("Enter the number of oldies: "))
result = (videos * 3.00) + (oldies * 2.00)
print("The total cost is","$",result)
